local display = false

local time = 60  -- Czas w sekundach
local answers = 6  -- Liczba potrzebych poprawnych odpowiedzi
local interval = 5 -- czas interwałów tasowania elementów w sekundach
local incorrectAnswers = 1 -- Liczba możliwych nie poprawnych odpowiedzi

RegisterCommand("klikanie", function(source, args)
    SetDisplay(not display)
end)

RegisterNUICallback("exit", function(data)
    SetDisplay(false)
end)

RegisterNUICallback("resultWin", function(data)
    print("Win")
end)

RegisterNUICallback("resultLoss", function(data)
    print("Loss")
end)

Citizen.CreateThread(function()
    while display do
        Citizen.Wait(0)
        DisableControlAction(0, 1, display) 
        DisableControlAction(0, 2, display) 
        DisableControlAction(0, 142, display) 
        DisableControlAction(0, 18, display)
        DisableControlAction(0, 322, display)
        DisableControlAction(0, 106, display) 
    end
end)

function SetDisplay(bool)
    display = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = "ui",
        status = bool,
        time = time,
        answers = answers,
        interval = interval,
        incorrectAnswers = incorrectAnswers,
    })
end