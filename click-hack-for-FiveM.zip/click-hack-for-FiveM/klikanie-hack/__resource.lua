resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

client_script "nui.lua"

ui_page "klikanie-hack/index.html"
files {
    'klikanie-hack/index.html',
    'klikanie-hack/script.js',
    'klikanie-hack/style.css',
    'klikanie-hack/IBMPlexSans-Regular.ttf',
}
